package pl.altkom.meteo.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Gmina {
    @JsonProperty(value = "communeName")
    private String nazwaGminy = "";
    @JsonProperty(value = "districtName")
    private String nazwaPowiatu = "";
    @JsonProperty(value = "provinceName")
    private String nazwaWojewodztwa = "";

    public String getNazwaGminy() {
        return nazwaGminy;
    }

    public String getNazwaPowiatu() {
        return nazwaPowiatu;
    }

    public String getNazwaWojewodztwa() {
        return nazwaWojewodztwa;
    }

    @Override
    public String toString() {
        return String.format("gmina %s, powiat %s, woj. %s",
                nazwaGminy, nazwaPowiatu, nazwaWojewodztwa);
    }
}
