package pl.altkom.meteo.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ParametryCzujnika {
    @JsonProperty("paramName")
    private String nazwa = "";
    @JsonProperty("paramFormula")
    private String wzor = "";
    @JsonProperty("paramCode")
    private String kod = "";
    @JsonProperty("idParam")
    private Long id = null;

    public String getNazwa() {
        return nazwa;
    }

    public String getWzor() {
        return wzor;
    }

    public String getKod() {
        return kod;
    }

    public Long getId() {
        return id;
    }

    @Override
    public String toString() {
        return String.format("%id: %s (wzór %s, kod %s)", id, nazwa, wzor, kod);
    }
}
