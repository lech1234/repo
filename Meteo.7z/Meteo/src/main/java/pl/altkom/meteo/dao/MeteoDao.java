package pl.altkom.meteo.dao;

import pl.altkom.meteo.model.Czujnik;
import pl.altkom.meteo.model.DaneCzujnika;
import pl.altkom.meteo.model.StacjaPomiarowa;

import java.util.List;
import java.util.Optional;

public interface MeteoDao {
    List<StacjaPomiarowa> pobierzListeStacjiPomiarowych(String miasto);

    Optional<StacjaPomiarowa> znajdzNajblizszaStacjePomiarowa(double szerokosc, double dlugosc);

    Optional<List<Czujnik>> pobierzListeCzujnikow(long stationId);

    Optional<DaneCzujnika> pobierzDaneCzujnika(long sensorId);

    List<DaneCzujnika> pobierzDaneZeStacji(long idStacji);
}
