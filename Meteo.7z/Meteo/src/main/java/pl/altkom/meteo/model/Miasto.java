package pl.altkom.meteo.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Miasto {
    @JsonProperty("id")
    private Long id = null;
    @JsonProperty("name")
    private String nazwaMiasta = "";
    @JsonProperty("commune")
    private Gmina gmina = null;

    public Long getId() {
        return id;
    }

    public String getNazwaMiasta() {
        return nazwaMiasta;
    }

    public Gmina getGmina() {
        return gmina;
    }

    @Override
    public String toString() {
        return String.format("%s (%s)", nazwaMiasta, gmina);
    }
}
