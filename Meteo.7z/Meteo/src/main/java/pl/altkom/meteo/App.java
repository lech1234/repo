package pl.altkom.meteo;

import pl.altkom.meteo.dao.MeteoDao;
import pl.altkom.meteo.dao.MeteoDaoImpl;
import pl.altkom.meteo.model.DaneCzujnika;
import pl.altkom.meteo.service.MeteoService;
import pl.altkom.meteo.view.PokazDanych;

public class App {
    private PokazDanych p = new PokazDanych();
    private MeteoDao service = new MeteoDaoImpl();

    public static void main(String[] args) {
        MeteoService service = new MeteoService();

        service.pokazStacjePomiaroweWMiescie("Kraków");
//        service.pokazNajblizszaStacjePomiarowa( 50.0614300, 19.9365800);
//        service.pokazCzujniki(10121);
//        service.pokazDaneCzujnika(16377);
//        service.pokazDaneCzujnika(16516);
//        service.pokazDaneZeStacji(10121);
    }

}
