package pl.altkom.meteo.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class StacjaPomiarowa {
    private long id;
    @JsonProperty("stationName")
    private String nazwaStacji;
    @JsonProperty("gegrLat")
    private double szerokosc;
    @JsonProperty("gegrLon")
    private double dlugosc;
    @JsonProperty("city")
    private Miasto miasto;
    @JsonProperty("addressStreet")
    private String ulica;

    public long getId() {
        return id;
    }

    public String getNazwaStacji() {
        return nazwaStacji;
    }

    public double getSzerokosc() {
        return szerokosc;
    }

    public double getDlugosc() {
        return dlugosc;
    }

    public Miasto getMiasto() {
        return miasto;
    }

    public String getUlica() {
        return ulica;
    }

    @Override
    public String toString() {
        return String.format("StacjaPomiarowa{" +
                "id=%d, " +
                "nazwaStacji='%s', " +
                "szerokosc=%.6f, " +
                "dlugosc=%.6f, " +
                "miasto=%s, " +
                "ulica='%s'}",
                id, nazwaStacji, szerokosc, dlugosc, miasto, ulica);
    }
}
