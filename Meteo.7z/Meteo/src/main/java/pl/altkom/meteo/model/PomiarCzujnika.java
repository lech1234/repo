package pl.altkom.meteo.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.LocalDateTime;

public class PomiarCzujnika {
    @JsonProperty("date")
    private LocalDateTime data;
    @JsonProperty("value")
    private double wartosc;

    public LocalDateTime getData() {
        return data;
    }

    public double getWartosc() {
        return wartosc;
    }

    public void setData(String data) {
        data = data.replace(' ', 'T');
        this.data = LocalDateTime.parse(data);
    }

    @Override
    public String toString() {
        return "PomiarCzujnika{" +
                "data='" + data + '\'' +
                ", wartosc=" + wartosc +
                '}';
    }
}
