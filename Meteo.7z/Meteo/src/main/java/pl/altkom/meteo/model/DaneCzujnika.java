package pl.altkom.meteo.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class DaneCzujnika {
    @JsonProperty("key")
    private String kod;
    @JsonProperty("values")
    private Map<LocalDateTime, Double> wartosci;

    public String getKod() {
        return kod;
    }

    public Map<LocalDateTime, Double> getWartosci() {
        return wartosci;
    }

    public void setWartosci(List<PomiarCzujnika> list) {
        this.wartosci = list.stream()
                .collect(Collectors.toMap(
                        PomiarCzujnika::getData,
                        PomiarCzujnika::getWartosc,
                        (x, y) -> x,
                        LinkedHashMap::new)
                );
    }

    @Override
    public String toString() {
        return String.format("%s dane: %s", kod, wartosci);
    }
}
