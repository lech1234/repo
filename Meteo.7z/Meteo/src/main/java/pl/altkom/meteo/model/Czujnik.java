package pl.altkom.meteo.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Czujnik {
    @JsonProperty("id")
    private Long idCzujnika = null;
    @JsonProperty("stationId")
    private Long idStacji = null;
    @JsonProperty("param")
    private ParametryCzujnika parametryCzujnika = null;

    public long getIdCzujnika() {
        return idCzujnika;
    }

    public long getIdStacji() {
        return idStacji;
    }

    public ParametryCzujnika getParametryCzujnika() {
        return parametryCzujnika;
    }

    @Override
    public String toString() {
        return String.format("id %d, id stacji pomiarowej %d (%s)", idCzujnika, idStacji, parametryCzujnika);
    }
}
