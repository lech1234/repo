package pl.altkom.meteo.view;

import pl.altkom.meteo.model.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public class PokazDanych {

    private void separatorTabeliStacjiPomiarowych() {
        final String SEPARATOR
                = "------+--------------------------------+-----------+-----------+-----------------------------";
        System.out.println(SEPARATOR);
    }

    private void naglowekTabeliStacjiPomiarowych() {
        separatorTabeliStacjiPomiarowych();
        System.out.println("ID    | Nazwa                          | Szer geog | Dług geog | Adres");
        separatorTabeliStacjiPomiarowych();
    }

    private void wierszTabeliStacjiPomiarowych(StacjaPomiarowa stacja) {
        final String format = "%5d | %-30s | %9.6f | %9.6f | %-30s%n";
        System.out.printf(format,
                stacja.getId(),
                stacja.getNazwaStacji(),
                stacja.getSzerokosc(),
                stacja.getDlugosc(),
                stacja.getUlica());
    }

    public void tabelaStacjiPomiarowych(List<StacjaPomiarowa> stacje) {
        if (stacje.isEmpty()) {
            System.out.println("Brak danych\n");
            return;
        }
        Miasto miasto = stacje.get(0).getMiasto();
        System.out.printf("%nLista stacji pomiarowych dla miejscowości: %s%n", miasto);
        naglowekTabeliStacjiPomiarowych();
        stacje.forEach(this::wierszTabeliStacjiPomiarowych);
        separatorTabeliStacjiPomiarowych();
    }

    public void tabelaNajblizszejStacjiPomiarowej(double szerokosc, double dlugosc,
                                                  Optional<StacjaPomiarowa> opcjonalnaStacjaPomiarowa) {
        if (opcjonalnaStacjaPomiarowa.isPresent()) {
            StacjaPomiarowa stacjaPomiarowa = opcjonalnaStacjaPomiarowa.get();
            System.out.printf("Stacja pomiarowa najbliższa lokalizacji (%.6f, %.6f):%n", szerokosc, dlugosc);
            naglowekTabeliStacjiPomiarowych();
            wierszTabeliStacjiPomiarowych(stacjaPomiarowa);
            separatorTabeliStacjiPomiarowych();
        } else {
            System.out.println("Nie znaleziono stacji pomiarowej");
        }
    }

    private void separatorTabeliCzujnikow() {
        final String SEPARATOR
                = "------+--------+-----------------------";
        System.out.println(SEPARATOR);
    }

    private void naglowekTabeliCzujnikow() {
        separatorTabeliCzujnikow();
        System.out.println("ID    | Symbol | Nazwa");
        separatorTabeliCzujnikow();
    }

    private void wierszTabeliCzujnikow(Czujnik czujnik) {
        final String format = "%5d | %-6s | %s%n";
        ParametryCzujnika param = czujnik.getParametryCzujnika();
        System.out.printf(format,
                czujnik.getIdCzujnika(),
                param.getWzor(),
                param.getNazwa());
    }

    public void tabelaCzujnikow(List<Czujnik> czujniki) {
        if (czujniki.isEmpty()) {
            System.out.println("Brak danych\n");
            return;
        }
        long idStacji = czujniki.get(0).getIdStacji();
        System.out.printf("Lista czujników dla stacji nr %d:%n", idStacji);
        naglowekTabeliCzujnikow();

        czujniki.stream().forEach(this::wierszTabeliCzujnikow);
        separatorTabeliCzujnikow();
    }

    private void separatorTabeliDanychCzujnika() {
        final String SEPARATOR
                = "-----------+-------+------------";
        System.out.println(SEPARATOR);
    }

    private void naglowekTabeliDanychCzujnika(String kod) {
        separatorTabeliDanychCzujnika();
        System.out.println("Data       | Czas  | " + kod);
        separatorTabeliDanychCzujnika();
    }

    private void wierszTabeliDanychCzujnika(Czujnik czujnik) {
        final String format = "%5d | %-6s | %s%n";
        ParametryCzujnika param = czujnik.getParametryCzujnika();
        System.out.printf(format,
                czujnik.getIdCzujnika(),
                param.getWzor(),
                param.getNazwa());
    }

    public void tabelaDanychCzujnika(DaneCzujnika dane) {
        naglowekTabeliDanychCzujnika(dane.getKod());
        dane.getWartosci().forEach((k, w) ->
                System.out.printf("%s | %s | %10.6f%n",
                        k.toLocalDate(),
                        k.toLocalTime(),
                        w));
        separatorTabeliDanychCzujnika();
    }

    private void separatorTabeliDanychZeStacji(List<DaneCzujnika> daneCzujnikow) {
        int liczbaCzujnikow = daneCzujnikow.size();
        StringBuilder separator = new StringBuilder("-----------+-------");
        for (int i =0;i<liczbaCzujnikow;i++){
            separator.append("+------------");
        }
        System.out.println(separator.toString());
    }

    private void naglowekTabeliDanychZeStacji(List<DaneCzujnika> daneCzujnikow) {
        separatorTabeliDanychZeStacji(daneCzujnikow);
        System.out.print("Data       | Czas  ");
        for (DaneCzujnika dane : daneCzujnikow) {
            System.out.printf("| %-10s ", dane.getKod());
        }
        System.out.println();
        separatorTabeliDanychZeStacji(daneCzujnikow);
    }

    public void tabelaDanychZeStacji(long idStacji, List<DaneCzujnika> daneCzujnikow) {
        System.out.printf("Dane pomiarowe ze stacji nr %d%n", idStacji);
        naglowekTabeliDanychZeStacji(daneCzujnikow);
        Set<LocalDateTime> datyPomiarow = daneCzujnikow.get(0).getWartosci().keySet();
        for (LocalDateTime data: datyPomiarow) {
            System.out.printf("%s | %s", data.toLocalDate(), data.toLocalTime());
            for (DaneCzujnika dane : daneCzujnikow) {
                System.out.printf(" | %10.6f", dane.getWartosci().get(data));
            }
            System.out.println();
        }
        separatorTabeliDanychZeStacji(daneCzujnikow);
    }
}
