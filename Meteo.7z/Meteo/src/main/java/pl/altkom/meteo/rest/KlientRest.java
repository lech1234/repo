package pl.altkom.meteo.rest;

import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;
import pl.altkom.meteo.model.Czujnik;
import pl.altkom.meteo.model.DaneCzujnika;
import pl.altkom.meteo.model.StacjaPomiarowa;

import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import java.util.List;

// https://powietrze.gios.gov.pl/pjp/content/api

public class KlientRest {

    private final String BASE = "http://api.gios.gov.pl/pjp-api/rest/";
    private final WebTarget baseTarget = ClientBuilder.newClient()
            .target(BASE)
            .register(JacksonJsonProvider.class);

    public List<StacjaPomiarowa> pobierzStacjePomiarowe() {
        return baseTarget
                .path("station/findAll")
                .request(MediaType.APPLICATION_JSON)
                .get(new GenericType<List<StacjaPomiarowa>>() {
                });
    }

    public List<Czujnik> pobierzCzujniki(long idCzujnika) {
        return baseTarget
                .path("station/sensors/{stationId}")
                .resolveTemplate("stationId", idCzujnika)
                .request(MediaType.APPLICATION_JSON)
                .get(new GenericType<List<Czujnik>>() {
                });
    }

    public DaneCzujnika pobierzDaneCzujnika(Long idCzujnika) {
        return baseTarget
                .path("data/getData/{sensorId}")
                .resolveTemplate("sensorId", idCzujnika)
                .request(MediaType.APPLICATION_JSON)
                .get(DaneCzujnika.class);
    }
}
