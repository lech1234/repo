package pl.altkom.meteo.dao;

import pl.altkom.meteo.model.Czujnik;
import pl.altkom.meteo.model.DaneCzujnika;
import pl.altkom.meteo.model.StacjaPomiarowa;
import pl.altkom.meteo.rest.KlientRest;

import javax.ws.rs.InternalServerErrorException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class MeteoDaoImpl implements MeteoDao {
    private KlientRest klient = new KlientRest();

    @Override
    public List<StacjaPomiarowa> pobierzListeStacjiPomiarowych(String nazwaMiasta) {
        List<StacjaPomiarowa> stacje = klient.pobierzStacjePomiarowe();
        return stacje.stream()
                .filter(s -> s.getMiasto().getNazwaMiasta().equalsIgnoreCase(nazwaMiasta))
                .collect(Collectors.toList());
    }

    @Override
    public Optional<StacjaPomiarowa> znajdzNajblizszaStacjePomiarowa(double szerokosc, double dlugosc) {
        List<StacjaPomiarowa> stacje = klient.pobierzStacjePomiarowe();
        return stacje.stream()
                .min(Comparator.comparingDouble(
                        s -> {
                            double deltaSzerokosc = s.getSzerokosc() - szerokosc;
                            double deltaDlugosc = s.getDlugosc() - dlugosc;
                            return deltaSzerokosc * deltaSzerokosc + deltaDlugosc * deltaDlugosc;
                        }));
    }

    @Override
    public Optional<List<Czujnik>> pobierzListeCzujnikow(long idStacji) {
        try {
            return Optional.of(klient.pobierzCzujniki(idStacji));
        } catch (InternalServerErrorException e) {
            return Optional.empty();
        }
    }

    @Override
    public Optional<DaneCzujnika> pobierzDaneCzujnika(long idCzujnika) {
        try {
            return Optional.of(klient.pobierzDaneCzujnika(idCzujnika));
        } catch (InternalServerErrorException e) {
            return Optional.empty();
        }
    }

    @Override
    public List<DaneCzujnika> pobierzDaneZeStacji(long idStacji) {
        List<DaneCzujnika> daneCzujnikow = new ArrayList<>();
        Optional<List<Czujnik>> opcjonalnaListaCzujnikow = pobierzListeCzujnikow(idStacji);
        if (opcjonalnaListaCzujnikow.isPresent()) {
            List<Czujnik> listaCzujnikow = opcjonalnaListaCzujnikow.get();
            for (Czujnik czujnik : listaCzujnikow) {
                try {
                     DaneCzujnika dane = klient.pobierzDaneCzujnika(czujnik.getIdCzujnika());
                     if (dane!=null) {
                         daneCzujnikow.add(dane);
                     }
                } catch (InternalServerErrorException e) {
                }
            }
        }
        return daneCzujnikow;
    }
}
