package pl.altkom.meteo.service;

import pl.altkom.meteo.dao.MeteoDao;
import pl.altkom.meteo.dao.MeteoDaoImpl;
import pl.altkom.meteo.model.Czujnik;
import pl.altkom.meteo.model.DaneCzujnika;
import pl.altkom.meteo.model.StacjaPomiarowa;
import pl.altkom.meteo.view.PokazDanych;

import java.util.List;
import java.util.Optional;

public class MeteoService {
    private MeteoDao dao = new MeteoDaoImpl();
    private PokazDanych prezentacja = new PokazDanych();

    public void pokazStacjePomiaroweWMiescie(String nazwaMiasta) {
        List<StacjaPomiarowa> stacjePomiarowe = dao.pobierzListeStacjiPomiarowych(nazwaMiasta);
        prezentacja.tabelaStacjiPomiarowych(stacjePomiarowe);
    }

    public void pokazNajblizszaStacjePomiarowa(double szerokosc, double dlugosc) {
        Optional<StacjaPomiarowa> stacjaPomiarowa = dao.znajdzNajblizszaStacjePomiarowa(szerokosc, dlugosc);
        prezentacja.tabelaNajblizszejStacjiPomiarowej(szerokosc, dlugosc, stacjaPomiarowa);
    }

    public void pokazCzujniki(long idStacji) {
        List<Czujnik> czujniki = dao.pobierzListeCzujnikow(idStacji).get();
        prezentacja.tabelaCzujnikow(czujniki);
    }

    public void pokazDaneCzujnika(long idCzujnika) {
        DaneCzujnika data = dao.pobierzDaneCzujnika(idCzujnika).get();
        prezentacja.tabelaDanychCzujnika(data);
    }

    public void pokazDaneZeStacji(long idStacji) {
        List<DaneCzujnika> daneCzujnikow = dao.pobierzDaneZeStacji(idStacji);
        prezentacja.tabelaDanychZeStacji(idStacji, daneCzujnikow);
    }

}

